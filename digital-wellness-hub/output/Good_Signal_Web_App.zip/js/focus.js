(function () {
  const $ = (selector) => document.querySelector(selector);
  const display = $('[data-timer-display]');
  if (!display) return;

  const startButton = $('[data-timer-start]');
  const pauseButton = $('[data-timer-pause]');
  const finishButton = $('[data-timer-finish]');
  const resetButton = $('[data-timer-reset]');
  const distractionButton = $('[data-distraction]');
  const status = $('[data-focus-status]');
  const taskInput = $('#focus-task');
  const breakSelect = $('#break-length');
  const modeLabel = $('[data-focus-mode]');
  const timerLabel = $('[data-timer-label]');
  const timerTask = $('[data-timer-task]');
  const distractionCount = $('[data-distraction-count]');
  const ring = $('[data-timer-ring]');
  const history = $('[data-session-history]');
  const todayTotal = $('[data-today-total]');
  const todayBar = $('[data-today-bar]');
  const todaySummary = $('[data-today-summary]');
  const durationButtons = Array.from(document.querySelectorAll('[data-duration]'));
  const setupControls = [taskInput, breakSelect, ...durationButtons].filter(Boolean);

  const STORAGE_KEY = 'good-signal-focus-sessions';
  let focusMinutes = 25;
  let breakMinutes = Number(breakSelect && breakSelect.value) || 5;
  let mode = 'focus';
  let totalSeconds = focusMinutes * 60;
  let remainingSeconds = totalSeconds;
  let deadline = null;
  let timerId = null;
  let distractions = 0;
  let sessionStarted = false;
  let historyClearPending = false;

  function readSessions() {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      const value = JSON.parse(raw || '[]');
      if (!Array.isArray(value)) return [];
      return value.filter((item) => item && typeof item === 'object' &&
        typeof item.date === 'string' && typeof item.day === 'string' &&
        typeof item.task === 'string' && Number.isFinite(Number(item.minutes)) &&
        Number.isFinite(Number(item.plannedMinutes)));
    } catch (_) {
      return [];
    }
  }

  function writeSessions(sessions) {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions.slice(0, 30)));
      return true;
    } catch (_) {
      return false;
    }
  }

  function todayKey(date = new Date()) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  }

  function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60).toString().padStart(2, '0');
    const remainder = (seconds % 60).toString().padStart(2, '0');
    return `${minutes}:${remainder}`;
  }

  function updateTimer() {
    display.textContent = formatTime(Math.max(0, remainingSeconds));
    const progress = totalSeconds ? Math.min(100, Math.max(0, ((totalSeconds - remainingSeconds) / totalSeconds) * 100)) : 0;
    if (ring) ring.style.setProperty('--timer-progress', `${progress}%`);
    if (timerTask) timerTask.textContent = mode === 'break' ? 'Step away. Let your brain reset.' : (taskInput.value.trim() || 'Choose one task below.');
    if (modeLabel) modeLabel.textContent = mode === 'break' ? 'Break' : 'Focus';
    if (timerLabel) timerLabel.textContent = mode === 'break' ? 'Break time' : 'Focus time';
    if (distractionButton) distractionButton.hidden = mode === 'break';
    if (distractionCount && distractionCount.parentElement) distractionCount.parentElement.hidden = mode === 'break';
  }

  function setStatus(message) {
    if (status) status.textContent = message;
  }

  function setSetupLocked(locked) {
    setupControls.forEach((control) => { control.disabled = locked; });
  }

  function setRunning(running) {
    startButton.hidden = running;
    pauseButton.hidden = !running;
    finishButton.hidden = !running || mode !== 'focus';
    pauseButton.textContent = 'Pause';
    if (distractionButton) distractionButton.disabled = !running || mode !== 'focus';
  }

  function stopTimer() {
    if (timerId !== null) window.clearInterval(timerId);
    timerId = null;
    deadline = null;
    setRunning(false);
  }

  function tick() {
    if (deadline === null) return;
    remainingSeconds = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
    updateTimer();
    if (remainingSeconds <= 0) finishCurrentMode();
  }

  function runClock() {
    deadline = Date.now() + remainingSeconds * 1000;
    timerId = window.setInterval(tick, 250);
    tick();
  }

  function startTimer() {
    if (mode === 'focus' && !taskInput.value.trim()) {
      taskInput.focus();
      setStatus('Name one task first, so this block has somewhere to go.');
      return;
    }
    if (mode === 'focus') {
      sessionStarted = true;
      setSetupLocked(true);
    }
    stopTimer();
    setRunning(true);
    pauseButton.focus();
    setStatus(mode === 'break' ? 'Break started. Leave the screen if you can.' : 'Session started. One task is enough.');
    runClock();
  }

  function pauseTimer() {
    if (timerId === null) return;
    remainingSeconds = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
    if (timerId !== null) window.clearInterval(timerId);
    timerId = null;
    deadline = null;
    updateTimer();
    pauseButton.textContent = 'Resume';
    pauseButton.hidden = false;
    startButton.hidden = true;
    finishButton.hidden = mode !== 'focus';
    if (distractionButton) distractionButton.disabled = true;
    setStatus('Paused. Resume when you are ready, or reset to choose a new block.');
    if (remainingSeconds === 0) finishCurrentMode();
  }

  function resetTimer() {
    stopTimer();
    mode = 'focus';
    totalSeconds = focusMinutes * 60;
    remainingSeconds = totalSeconds;
    distractions = 0;
    sessionStarted = false;
    if (distractionCount) distractionCount.textContent = '0';
    startButton.textContent = 'Start session';
    startButton.hidden = false;
    pauseButton.hidden = true;
    finishButton.hidden = true;
    setSetupLocked(false);
    setStatus('A small block is enough to start.');
    updateTimer();
  }

  function finishCurrentMode() {
    const focusWasInControls = document.activeElement === pauseButton || document.activeElement === finishButton;
    stopTimer();
    if (mode === 'break') {
      resetTimer();
      if (focusWasInControls) startButton.focus();
      setStatus('Break complete. You can start another focus block when you are ready.');
      return;
    }
    const saved = saveSession(true);
    mode = 'break';
    totalSeconds = breakMinutes * 60;
    remainingSeconds = totalSeconds;
    sessionStarted = false;
    setSetupLocked(true);
    startButton.textContent = `Start ${breakMinutes}-minute break`;
    startButton.hidden = false;
    pauseButton.hidden = true;
    finishButton.hidden = true;
    if (focusWasInControls) startButton.focus();
    setStatus(saved ? 'Focus block complete. Take the break - it is part of the work.' : 'Focus block complete, but this browser could not save it to your history.');
    updateTimer();
  }

  function finishEarly() {
    if (!sessionStarted || mode !== 'focus') return;
    if (timerId !== null) {
      remainingSeconds = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
      if (timerId !== null) window.clearInterval(timerId);
      timerId = null;
      deadline = null;
    }
    const saved = saveSession(false);
    resetTimer();
    startButton.focus();
    setStatus(saved ? 'Saved as a partial session. That still counts as useful information.' : 'Session ended, but this browser could not save it to your history.');
  }

  function saveSession(completed) {
    const elapsedSeconds = Math.max(0, totalSeconds - remainingSeconds);
    const sessions = readSessions();
    sessions.unshift({
      date: new Date().toISOString(),
      day: todayKey(),
      task: taskInput.value.trim() || 'Untitled session',
      seconds: elapsedSeconds,
      minutes: Math.floor(elapsedSeconds / 60),
      plannedMinutes: focusMinutes,
      completed,
      distractions
    });
    const stored = writeSessions(sessions);
    renderHistory();
    return stored;
  }

  function renderHistory() {
    const sessions = readSessions();
    const today = sessions.filter((session) => session.day === todayKey());
    const total = today.reduce((sum, session) => sum + (Number(session.minutes) || 0), 0);
    if (todayTotal) todayTotal.textContent = `${total} min`;
    if (todayBar) todayBar.style.width = `${Math.min(100, (total / 120) * 100)}%`;
    if (todaySummary) todaySummary.textContent = total ? `${today.length} block${today.length === 1 ? '' : 's'} logged today. A 2-hour goal is only a guide, not a rule.` : 'Complete one focus block to start your record.';
    if (!history) return;
    if (!sessions.length) {
      history.innerHTML = '<div class="empty-state"><strong>No sessions yet.</strong><p>Your first completed or partial block will appear here.</p></div>';
      return;
    }
    history.innerHTML = sessions.slice(0, 8).map((session) => {
      const parsedDate = new Date(session.date);
      const time = Number.isNaN(parsedDate.getTime()) ? 'Date unavailable' : parsedDate.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
      const state = session.completed ? 'Completed' : 'Partial';
      const seconds = Number.isFinite(Number(session.seconds)) ? Math.max(0, Number(session.seconds)) : Math.max(0, Number(session.minutes) || 0) * 60;
      const duration = seconds < 60 ? `${seconds} sec` : `${Math.floor(seconds / 60)} min`;
      return `<article class="session-row"><div class="session-status ${session.completed ? 'is-complete' : ''}">${session.completed ? '✓' : '·'}</div><div><strong>${escapeHtml(session.task)}</strong><span>${time} · ${duration} · ${state}</span></div><span class="session-distractions">${Number(session.distractions) || 0} check-ins</span></article>`;
    }).join('');
  }

  function renderClearConfirmation() {
    if (!history) return;
    const existing = history.querySelector('[data-history-confirmation]');
    if (existing) existing.remove();
    const panel = document.createElement('div');
    panel.dataset.historyConfirmation = '';
    panel.className = 'history-confirmation';
    panel.setAttribute('role', 'status');
    panel.innerHTML = '<span>Clear all focus history stored in this browser?</span> <button type="button" data-history-clear-confirm>Clear history</button> <button type="button" data-history-clear-cancel>Keep history</button>';
    history.prepend(panel);
    panel.querySelector('[data-history-clear-confirm]').addEventListener('click', () => {
      const cleared = writeSessions([]);
      if (cleared) {
        historyClearPending = false;
        renderHistory();
        setStatus('Focus history cleared from this browser.');
      } else {
        panel.textContent = 'This browser could not clear the saved focus history.';
      }
    });
    panel.querySelector('[data-history-clear-cancel]').addEventListener('click', () => {
      historyClearPending = false;
      panel.remove();
    });
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[char]));
  }

  durationButtons.forEach((button) => button.addEventListener('click', () => {
    if (sessionStarted || mode === 'break') return;
    durationButtons.forEach((item) => {
      item.classList.remove('is-selected');
      item.setAttribute('aria-pressed', 'false');
    });
    button.classList.add('is-selected');
    button.setAttribute('aria-pressed', 'true');
    focusMinutes = Number(button.dataset.duration) || 25;
    totalSeconds = focusMinutes * 60;
    remainingSeconds = totalSeconds;
    updateTimer();
  }));

  if (breakSelect) breakSelect.addEventListener('change', () => { breakMinutes = Number(breakSelect.value) || 5; });
  taskInput.addEventListener('input', updateTimer);
  startButton.addEventListener('click', startTimer);
  pauseButton.addEventListener('click', () => timerId !== null ? pauseTimer() : startTimer());
  finishButton.addEventListener('click', finishEarly);
  resetButton.addEventListener('click', () => {
    if (sessionStarted && !window.confirm('Reset this focus block and discard its unsaved time?')) return;
    resetTimer();
  });
  distractionButton.addEventListener('click', () => {
    if (!sessionStarted || mode !== 'focus' || timerId === null) return;
    distractions += 1;
    if (distractionCount) distractionCount.textContent = String(distractions);
    setStatus('Noted. Return to the task when you can.');
  });
  document.addEventListener('visibilitychange', () => {
    if (timerId !== null) tick();
  });
  window.addEventListener('beforeunload', (event) => {
    if (!sessionStarted || mode !== 'focus') return;
    event.preventDefault();
    event.returnValue = '';
    return '';
  });
  const clearHistoryButton = $('[data-history-clear]');
  if (clearHistoryButton) clearHistoryButton.addEventListener('click', () => {
    historyClearPending = !historyClearPending;
    if (historyClearPending) renderClearConfirmation();
    else {
      const panel = history && history.querySelector('[data-history-confirmation]');
      if (panel) panel.remove();
    }
  });

  durationButtons.forEach((button) => button.setAttribute('aria-pressed', button.classList.contains('is-selected') ? 'true' : 'false'));
  if (distractionButton) distractionButton.disabled = true;
  updateTimer();
  renderHistory();
})();
