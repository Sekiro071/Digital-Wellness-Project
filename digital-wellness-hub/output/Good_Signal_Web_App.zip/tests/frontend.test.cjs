const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
async function mount(file, script = 'js/app.js', storage) {
  const dom = new JSDOM(read(file), { url: 'http://localhost/' + file, runScripts: 'outside-only', pretendToBeVisual: true });
  const w = dom.window;
  w.HTMLElement.prototype.scrollIntoView = function () {};
  w.HTMLElement.prototype.getClientRects = function () { return [1]; };
  w.fetch = async () => ({ ok: true, json: async () => JSON.parse(read('data/resources.json')) });
  if (storage) storage(w);
  w.eval(read('js/data.js'));
  w.eval(read(script));
  await new Promise(resolve => setImmediate(resolve));
  return dom;
}
const select = (w, selector, value) => { const el = w.document.querySelector(selector); el.value = value; el.dispatchEvent(new w.Event(el.type === 'search' ? 'input' : 'change', { bubbles: true })); };
test('bundled catalogue matches canonical data and has comparable source fields', () => {
  const dom = new JSDOM('', { runScripts: 'outside-only' });
  try {
    dom.window.eval(read('js/data.js'));
    const bundled = JSON.parse(JSON.stringify(dom.window.DW_RESOURCES));
    const canonical = JSON.parse(read('data/resources.json'));
    assert.deepEqual(bundled, canonical); assert.ok(canonical.length >= 8 && canonical.length <= 12);
    for (const resource of canonical) for (const key of ['purpose', 'platforms', 'pricing', 'privacy', 'accessibility', 'limitations', 'dateChecked', 'sourceType']) assert.ok(resource[key], `${resource.id}: ${key}`);
  } finally { dom.window.close(); }
});
test('price filters distinguish free open-source from freemium', async () => {
  const dom = await mount('pages/resources.html'); const w = dom.window, d = w.document;
  try {
    select(w, '#resource-pricing', 'free');
    const names = d.querySelector('[data-resource-grid]').textContent;
    assert.match(names, /uBlock Origin/); assert.match(names, /StayFocusd/); assert.doesNotMatch(names, /Cold Turkey/);
    select(w, '#resource-pricing', 'open-source');
    assert.match(d.querySelector('[data-resource-grid]').textContent, /Privacy Badger/);
    assert.doesNotMatch(d.querySelector('[data-resource-grid]').textContent, /StayFocusd/);
  } finally { w.close(); }
});
test('directory filters, saves, resets and enforces three comparison items', async () => {
  const dom = await mount('pages/resources.html'); const w = dom.window, d = w.document;
  try {
    assert.equal(d.querySelectorAll('.resource-card').length, 10);
    assert.equal(d.querySelector('[data-compare-modal]').hidden, true);
    select(w, '#resource-category', 'focus'); assert.equal(d.querySelectorAll('.resource-card').length, 3);
    select(w, '#resource-platform', 'Android'); assert.equal(d.querySelectorAll('.resource-card').length, 1);
    d.querySelector('.save-toggle').click();
    d.querySelector('[data-reset-filters]').click();
    const saved = d.querySelector('#resource-saved'); saved.checked = true; saved.dispatchEvent(new w.Event('change'));
    assert.equal(d.querySelectorAll('.resource-card').length, 1);
    d.querySelector('.save-toggle').click(); assert.equal(d.querySelectorAll('.resource-card').length, 0);
    d.querySelector('[data-reset-filters]').click();
    const buttons = d.querySelectorAll('.compare-toggle'); for (let i = 0; i < 4; i++) buttons[i].click();
    assert.equal(d.querySelector('[data-compare-count]').textContent, '3');
    d.querySelector('[data-open-compare]').focus();
    d.querySelector('[data-open-compare]').click();
    const modal = d.querySelector('[data-compare-modal]'); assert.equal(modal.hidden, false);
    assert.equal(d.activeElement, d.querySelector('[data-close-compare]'));
    assert.equal(d.querySelector('main').inert, true);
    d.dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    assert.equal(modal.hidden, true); assert.equal(d.querySelector('main').inert, false);
    assert.equal(d.activeElement, d.querySelector('[data-open-compare]'));
  } finally { w.close(); }
});
test('unavailable or malformed browser storage does not break directory actions', async () => {
  for (const broken of [false, true]) {
    const dom = await mount('pages/resources.html', 'js/app.js', w => {
      if (broken) Object.defineProperty(w, 'localStorage', { get() { throw new Error('blocked'); } });
      else w.localStorage.setItem('dw-saved', '{}');
    });
    try { dom.window.document.querySelector('.save-toggle').click(); assert.equal(dom.window.document.querySelector('.save-toggle').getAttribute('aria-pressed'), 'true'); }
    finally { dom.window.close(); }
  }
});
test('recommendations respect goal, platform and free budget together', async () => {
  const dom = await mount('pages/recommendations.html'); const w = dom.window, d = w.document;
  try {
    select(w, '#quiz-goal', 'focus'); select(w, '#quiz-device', 'Windows'); select(w, '#quiz-budget', 'free');
    d.querySelector('[data-quiz]').dispatchEvent(new w.Event('submit', { cancelable: true }));
    assert.equal(d.querySelectorAll('.result-card').length, 0);
    assert.match(d.querySelector('[data-recommendation-results]').textContent, /No exact fit/);
    select(w, '#quiz-device', 'Chrome');
    d.querySelector('[data-quiz]').dispatchEvent(new w.Event('submit', { cancelable: true }));
    assert.equal(d.querySelectorAll('.result-card').length, 1); assert.match(d.querySelector('.result-card').textContent, /StayFocusd/);
  } finally { w.close(); }
});
test('feedback preserves input after network failure and blocks duplicate submits', async () => {
  const dom = await mount('pages/feedback.html'); const w = dom.window, d = w.document;
  try {
    let calls = 0, reject;
    w.fetch = () => { calls++; return new Promise((_, no) => { reject = no; }); };
    for (const id of ['ease', 'found', 'guide']) d.querySelector('#' + id).selectedIndex = 1;
    d.querySelector('#improve').value = 'The filter was useful.';
    const form = d.querySelector('form');
    form.dispatchEvent(new w.Event('submit', { cancelable: true })); form.dispatchEvent(new w.Event('submit', { cancelable: true }));
    assert.equal(calls, 1); assert.equal(d.querySelector('button[type=submit]').disabled, true);
    reject(new w.TypeError('offline')); await new Promise(resolve => setImmediate(resolve));
    assert.equal(d.querySelector('#improve').value, 'The filter was useful.'); assert.equal(d.querySelector('button[type=submit]').disabled, false);
    assert.match(d.querySelector('[data-form-success]').textContent, /could not be reached/);
  } finally { w.close(); }
});
test('feedback requires deliberate answers and focuses the first missing response', async () => {
  const dom = await mount('pages/feedback.html'); const w = dom.window, d = w.document;
  try {
    let calls = 0; w.fetch = () => { calls++; };
    for (const id of ['ease', 'found', 'guide']) assert.equal(d.querySelector('#' + id).value, '');
    d.querySelector('form').dispatchEvent(new w.Event('submit', { cancelable: true }));
    assert.equal(calls, 0); assert.equal(d.activeElement.id, 'ease');
    assert.equal(d.querySelector('#ease').getAttribute('aria-invalid'), 'true');
  } finally { w.close(); }
});
test('theme follows system initially, persists a choice, and survives blocked storage', async () => {
  for (const blocked of [false, true]) {
    const dom = new JSDOM(read('pages/focus.html'), { url: 'http://localhost/focus', runScripts: 'outside-only' });
    const w = dom.window, d = w.document; let change;
    try {
      w.matchMedia = () => ({ matches: true, addEventListener: (_, callback) => { change = callback; } });
      if (blocked) Object.defineProperty(w, 'localStorage', { get() { throw new Error('blocked'); } });
      w.eval(read('js/theme.js'));
      assert.equal(d.documentElement.dataset.theme, 'dark');
      d.dispatchEvent(new w.Event('DOMContentLoaded'));
      const toggle = d.querySelector('.theme-toggle'); assert.ok(toggle);
      assert.match(toggle.getAttribute('aria-label'), /light mode/);
      toggle.click(); assert.equal(d.documentElement.dataset.theme, 'light');
      if (!blocked) assert.equal(w.localStorage.getItem('good-signal-theme'), 'light');
      change(); assert.equal(d.documentElement.dataset.theme, 'light');
    } finally { w.close(); }
  }
  const dom = new JSDOM(read('pages/feedback.html'), { url: 'http://localhost/feedback', runScripts: 'outside-only' });
  try { dom.window.localStorage.setItem('good-signal-theme', 'dark'); dom.window.eval(read('js/theme.js')); assert.equal(dom.window.document.documentElement.dataset.theme, 'dark'); }
  finally { dom.window.close(); }
});
test('focus uses elapsed wall time, freezes while paused and saves partial sessions', async () => {
  const dom = await mount('pages/focus.html', 'js/focus.js'); const w = dom.window, d = w.document;
  try {
    let now = 100000, tick;
    w.Date.now = () => now; w.setInterval = cb => { tick = cb; return 1; }; w.clearInterval = () => {};
    const task = d.querySelector('#focus-task'); task.value = 'Read chapter 3';
    d.querySelector('[data-timer-start]').focus(); d.querySelector('[data-timer-start]').click(); assert.equal(task.disabled, true);
    assert.equal(d.activeElement, d.querySelector('[data-timer-pause]'));
    now += 125000; tick(); assert.equal(d.querySelector('[data-timer-display]').textContent, '22:55');
    d.querySelector('[data-timer-pause]').click(); now += 900000; tick();
    assert.equal(d.querySelector('[data-timer-display]').textContent, '22:55');
    d.querySelector('[data-timer-finish]').click();
    assert.equal(d.activeElement, d.querySelector('[data-timer-start]'));
    const sessions = JSON.parse(w.localStorage.getItem('good-signal-focus-sessions'));
    assert.equal(sessions.length, 1); assert.equal(sessions[0].completed, false); assert.equal(sessions[0].task, 'Read chapter 3');
    assert.equal(task.disabled, false);
  } finally { w.close(); }
});
test('focus completion transitions to break and history clearing requires confirmation', async () => {
  const dom = await mount('pages/focus.html', 'js/focus.js'); const w = dom.window, d = w.document;
  try {
    let now = 0, tick; w.Date.now = () => now; w.setInterval = cb => { tick = cb; return 1; }; w.clearInterval = () => {};
    d.querySelector('#focus-task').value = 'Practice'; d.querySelector('[data-timer-start]').click();
    now = 1500000; tick();
    assert.equal(d.querySelector('[data-focus-mode]').textContent, 'Break');
    assert.equal(d.querySelector('[data-timer-display]').textContent, '05:00');
    assert.equal(JSON.parse(w.localStorage.getItem('good-signal-focus-sessions'))[0].minutes, 25);
    d.querySelector('[data-history-clear]').click();
    assert.equal(JSON.parse(w.localStorage.getItem('good-signal-focus-sessions')).length, 1);
    d.querySelector('[data-history-clear-confirm]').click();
    assert.equal(JSON.parse(w.localStorage.getItem('good-signal-focus-sessions')).length, 0);
  } finally { w.close(); }
});
test('focus does not fabricate a minute for an immediate finish', async () => {
  const dom = await mount('pages/focus.html', 'js/focus.js'); const w = dom.window, d = w.document;
  try {
    w.Date.now = () => 0; w.setInterval = () => 1; w.clearInterval = () => {};
    d.querySelector('#focus-task').value = 'Start reading';
    assert.equal(d.querySelector('[data-distraction]').disabled, true);
    d.querySelector('[data-timer-start]').click(); d.querySelector('[data-timer-finish]').click();
    const sessions = JSON.parse(w.localStorage.getItem('good-signal-focus-sessions'));
    assert.equal(sessions[0].minutes, 0); assert.equal(sessions[0].seconds, 0);
  } finally { w.close(); }
});
test('menu opens and Escape restores its closed state', async () => {
  const dom = await mount('pages/resources.html'); const w = dom.window, d = w.document;
  try {
    const button = d.querySelector('.menu-toggle'); button.click();
    assert.equal(button.getAttribute('aria-expanded'), 'true');
    d.dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    assert.equal(button.getAttribute('aria-expanded'), 'false');
    assert.equal(d.activeElement, button);
    assert.equal(d.querySelector('a[aria-current=page]').getAttribute('href'), '/explore');
  } finally { w.close(); }
});
